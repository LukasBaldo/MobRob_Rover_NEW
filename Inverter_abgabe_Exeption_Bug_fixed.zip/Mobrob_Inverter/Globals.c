#include "Globals.h"

#include <stdint.h> // need for data types


volatile float V_DC_link = 14.8; // nom Bat vaule

volatile int distance_180deg_ele_count = 0;
volatile float angle_phi = 0;
volatile float omega_mech_rps = 0;
