#ifndef READ_CURRENT_SENSOR
#define READ_CURRENT_SENSOR

#include <stdint.h> // need for data types
#include <DAVE.h>

float readCurrent(uint8_t);

#endif /* READ_CURRENT_SENSOR */
