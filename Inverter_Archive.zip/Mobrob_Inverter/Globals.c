#include "Globals.h"

#include <stdint.h> // need for data types


volatile float V_DC_link = 14.8; // nom Bat vaule
volatile float omega_ele_rads = 0;
volatile int distance_180deg_ele_count = 0;
