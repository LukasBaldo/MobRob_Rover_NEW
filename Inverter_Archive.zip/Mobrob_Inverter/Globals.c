#include <stdint.h> // need for data types


float V_DC_link;
volatile float omega_ele_rads;

float CAN_speed_ref;
uint8_t CAN_new_meassage = 0;// if 1 recived can data
uint8_t CAN_no_com_counter = 0;

// distacne vaule back over can
int distance_180deg_ele_count = 0;
float Speed_act = 0;
float distance = 0;
