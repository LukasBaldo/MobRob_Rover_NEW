/*
 * Steering_Servos.h
 *
 *  Created on: 1 Jul 2022
 *      Author: lukas
 */

#ifndef STEERING_SERVOS_H_
#define STEERING_SERVOS_H_

#include "DAVE.h"

void Steering_set_Angles(float Angles_data_int[4]);
void Servo_NP_setting(void);

#endif /* STEERING_SERVOS_H_ */
